#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

struct put_ctrl_t{
    QString old_put;
    QString new_put;
    int brackets_cnt;
    int update_flag;
};
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT


public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QString puts;
    struct put_ctrl_t put_ctrl;
private:
    Ui::MainWindow *ui;
    int Priority(QString data);
    int mask_data(QString expression, QString *mask_buffer);
    int re_polish(QString *mask_buffer,QString *repolish,int length);
    double repolish_calculat(QString *repolish,int length);
    void calculate_result(QString expression);

private slots:
    void push_button_0();
    void push_button_1();

    void push_button_2();
    void push_button_3();
    void push_button_4();
    void push_button_5();
    void push_button_6();
    void push_button_7();
    void push_button_8();
    void push_button_9();
    void push_button_point();

    void push_button_left();
    void push_button_right();

    void push_button_plus();
    void push_button_mutil();
    void push_button_red();
    void push_button_div();
    void push_button_equal();

    void push_button_CE();
    void push_button_AC();
    void on_pushButton_2_clicked();
};
#endif // MAINWINDOW_H
